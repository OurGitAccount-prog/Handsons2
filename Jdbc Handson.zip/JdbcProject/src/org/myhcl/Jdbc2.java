package org.myhcl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Jdbc2 {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Connection con = null;
		PreparedStatement pst = null;
		try {
			String url = "jdbc:mysql://localhost:3306/hcldb";
			String username = "root";
			String password = "Santhosh@99";
			System.out.println("enter details");

			con = DriverManager.getConnection(url, username, password);
			pst = con.prepareStatement("insert into emp(id,name,address) values(?,?,?)");
			int id = Integer.parseInt(br.readLine());
			String name = br.readLine();
			String address = br.readLine();
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setNString(3, address);
			int i = pst.executeUpdate();
			if (i > 0) {
				System.out.println("successfully inserted");
			} else {
				System.out.println("successfully not inserted");

			}
			con.close();
		} catch (Exception e) {
			if (con != null) {
				try {
					con.close();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
	}

}
