package com.jdbc;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Jdbc1 {
	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Connection con=null;
		try {

			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hcldb", "root", "Santhosh@99");
			Statement stmt = con.createStatement();
			System.out.println("enter details:");
			int id = Integer.parseInt(br.readLine());
			String country_name = br.readLine();

			int i = stmt.executeUpdate("insert into country values(" + id + ",'" + country_name + "')");

			if (i > 0) {
				System.out.println("successfully inserted");
			} else {
				System.out.println("successfully not inserted");

			}
			con.close();
		} catch (Exception e) {
			if(con!=null){
				try {
					con.close();
				}
				catch(Exception e1) {
					e1.printStackTrace();
				}
			}
		}
			finally {
				if(con!=null) {
					try {
						con.close();}
						catch(Exception e2) {
							e2.printStackTrace();	
						}
				}
				}
		}
	}

}
