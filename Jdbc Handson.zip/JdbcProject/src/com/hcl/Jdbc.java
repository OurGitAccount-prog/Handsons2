package com.hcl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Jdbc {

	public static void main(String[] args) throws SQLException {
		try {

			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hcldb", "root", "Santhosh@99");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from meter");
			while (rs.next()) {
				int id = rs.getInt(1);
				String meter_number = rs.getString(2);
				int building_id = rs.getInt(3);
				System.out.println(id + " " + meter_number + " " + building_id);

			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
